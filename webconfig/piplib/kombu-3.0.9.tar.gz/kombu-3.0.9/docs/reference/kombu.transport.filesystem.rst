.. currentmodule:: kombu.transport.filesystem

.. automodule:: kombu.transport.filesystem

    .. contents::
        :local:

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:

